/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int320.midterm;

/**
 *
 * @author INT303
 */
public class NewClass {

    public static void main(String[] args) {
        Midterm m = new Midterm();
//        Object[] a = {1, 2, 3, 4, 4};
//        Object[] b = {1, 4, 3, 4, 4};
//        Object[] r = m.arrayIntersection(a, b);
//        for (Object object : r) {
//            System.out.println(object);
//        }
        int[] n1 = {1,2,3,4,5,5,6,7,7,8};
        m.getTopMostNumber(n1);
    }

}
