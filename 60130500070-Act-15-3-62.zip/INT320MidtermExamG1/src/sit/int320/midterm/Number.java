/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int320.midterm;

import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author INT303
 */
public class Number implements Comparable<Object>{
        public static CompareNumber CompareNumber = new CompareNumber();
        private int number;
        private ArrayList<Object> index = new ArrayList<>();
        
        public Number(int number,int index) {
            this.number = number;
            this.index.add(index);
        }
        public void add(int index){
            this.index.add(index);
        }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public ArrayList<Object> getIndex() {
        return index;
    }

    public void setIndex(ArrayList<Object> index) {
        this.index = index;
    }
        
        private static class CompareNumber implements Comparator<Number>{

            @Override
            public int compare(Number o1, Number o2) {
                int index = o2.index.size()-o1.index.size();
                if(index==0){
                    return o2.number-o1.number;
                }
                return index;
            }
        
        }
        @Override
        public int compareTo(Object o) {
            return this.number- (int)o;
        }
        
    
}
