/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int320.midterm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Midterm {
    
    public static void main(String[] args) {
        Midterm m = new Midterm();
        String exp = "(A*B)+(C-F)+(Z*H)";
        
        System.out.println(m.infixToPostfix(exp));
    }
    
    public static String getTopMostNumber(int[] numbers) {
        if (numbers.length != 0) {
            Map<Object, Number> m = new HashMap<>();
            for (int i = 0; i < numbers.length; i++) {
                if (m.get(numbers[i]) == null) {
                    m.put(numbers[i], new Number(numbers[i], i));
                } else {
                    m.get(numbers[i]).add(i);
                }
            }
            List<Number> listSort = new ArrayList(m.values());
            Collections.sort(listSort, Number.CompareNumber);
            String result = listSort.get(0).getNumber() + " (" + listSort.get(0).getIndex().size() + ") : " + listSort.get(0).getIndex();
            return result;
        }
        return null;
    }
    
    public static String infixToPostfix(String exp) {
        StringBuilder result = new StringBuilder(128);
        StringTokenizer stk = new StringTokenizer(exp, " ()+-*/%", true);
        LinkedList<String> stack = new LinkedList();
        String token;
        while (stk.hasMoreElements()) {
            token = stk.nextToken();
            if (token.equals(" ")) {
                continue;
            } else if (!isOperator(token)) {
                result.append(" ");
                result.append(token);
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !"(".equals(stack.peek())) {
                    result.append(" ");
                    result.append(stack.pop());
                }
                if (!stack.isEmpty()) {
                    stack.pop();
                }
            } else {
                while (!stack.isEmpty() && isOperatorLevel(token) <= isOperatorLevel(stack.peek())) {
                    result.append(" " + stack.pop());
                }
                stack.push(token);
            }

        }
        while (!stack.isEmpty()) {
            result.append(" ");
            result.append(stack.pop());
        }
        return result.toString().trim();
    }
    
    public static boolean isOperator(String token) {
        switch (token) {
            case "(":            
            case ")":
            case "+":
            case "-":
            case "*":
            case "/":
            case "%":
                return true;
        }
        return false;
    }

    public static int isOperatorLevel(String token) {
        switch (token) {
            case "(":            
            case ")":
                return 0;
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
            case "%":
                return 2;
        }
        return -1;
    }

    public static Object[] arrayIntersection(Object[] obj1, Object[] obj2) {
        return arrayIntersection(obj1, obj2, null);
    }
    
    public static Object[] arrayIntersection(Object[] obj1, Object[] obj2, Comparator c) {
        Set setA, setB;
        if (c == null) {
            setA = new TreeSet();
            setB = new TreeSet();
        } else {
            setA = new TreeSet(c);
            setB = new TreeSet(c);
        }
        setA.addAll(Arrays.asList(obj1));
        setB.addAll(Arrays.asList(obj2));
        setA.retainAll(setB);
        return setA.toArray();
    }
    
}
