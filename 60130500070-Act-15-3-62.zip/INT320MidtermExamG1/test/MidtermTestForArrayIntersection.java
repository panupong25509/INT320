/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import int320midtermexam.TestIntersection;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Khaitong Lim
 */
public class MidtermTestForArrayIntersection extends TestIntersection {

}
