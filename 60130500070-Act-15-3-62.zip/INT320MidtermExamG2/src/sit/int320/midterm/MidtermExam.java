/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int320.midterm;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class MidtermExam {
    public static String getTopMostNumber(int[] numbers) {
        return null;
    }

    public static String infixToPostfix(String exp) {
        StringBuilder result = new StringBuilder(128);
       return result.toString().trim();
    }

    public static Object[] arrayUnion(Object[] obj1, Object[] obj2) {
        return arrayUnion(obj1, obj2, null);
    }

    public static Object[] arrayUnion(Object[] obj1, Object[] obj2, Comparator c) {
        Set setA, setB;
        if (c == null) {
            setA = new TreeSet();
            setB = new TreeSet();
        } else {
            setA = new TreeSet(c);
            setB = new TreeSet(c);
        }
        setA.addAll(Arrays.asList(obj1));
        setB.addAll(Arrays.asList(obj2));
        setA.addAll(setB);
        return setA.toArray();
    }
}
